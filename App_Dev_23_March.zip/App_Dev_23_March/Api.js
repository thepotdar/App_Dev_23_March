// api.js
const API_BASE_URL = 'https://developer.edamam.com/admin/applications'; // Base URL of the Edamam API
const API_ID = 'API_ID_01'; // Your Edamam API ID
const API_KEY = 'API_KEY_02'; // Your Edamam API Key

// Function to fetch recipes based on user query


export const fetchRecipes = async (query) => {
  const response = await fetch(`${https://developer.edamam.com/admin/applications}/search?q=${query}&app_id=${API_ID_01}&app_key=${API_API_KEY_02}`);
  if (!response.ok) {
    throw new Error('Failed to fetch recipes');
  }
  const data = await response.json();
  return data.hits; // Return an array of recipe objects
};

