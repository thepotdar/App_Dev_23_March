import React, { useState } from 'react';

const Home = () => {
  // State to manage the search query
  const [searchQuery, setSearchQuery] = useState('');

  // Function to handle search form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Logic to handle search (e.g., fetch recipes based on searchQuery)
    
    console.log('Search query:', searchQuery);
    
  };

  return (
    <div>
      <h1>Food Recipe Explorer</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search for recipes..."
        />
        <button type="submit">Search</button>
      </form>
      
    </div>
  );
};

export default Home;

