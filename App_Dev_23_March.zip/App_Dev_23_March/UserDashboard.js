import React from 'react';

const UserDashboard = ({ searchHistory, favoriteRecipes }) => {
  return (
    <div>
      <h2>User Dashboard</h2>
      <div>
        <h3>Search History</h3>
        <ul>
          {searchHistory.map((search, index) => (
            <li key={index}>{search}</li>
          ))}
        </ul>
      </div>
      <div>
        <h3>Favorite Recipes</h3>
        <ul>
          {favoriteRecipes.map((recipe, index) => (
            <li key={index}>{recipe.label}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default UserDashboard;

