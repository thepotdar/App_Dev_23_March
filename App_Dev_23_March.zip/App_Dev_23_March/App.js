import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import PrivateRoute from './PrivateRoute';
import Home from './Home';
import Login from './Login';
import RecipeDetails from './RecipeDetails';
import UserDashboard from './UserDashboard';

const App = () => {
  return (
    <Router>
      <Switch>
        <Route path="/login" component={Login} />
        <PrivateRoute path="/dashboard" component={UserDashboard} />
        <PrivateRoute path="/recipe/:id" component={RecipeDetails} />
        <Route path="/" component={Home} />
      </Switch>
    </Router>
  );
};

export default App;

