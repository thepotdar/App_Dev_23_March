import React from 'react';

const RecipeDetails = ({ recipe }) => {
  if (!recipe) {
    return <div>No recipe selected</div>;
  }

  const { label, image, ingredients, calories, totalTime, cuisineType, mealType } = recipe;

  return (
    <div>
      <h2>{label}</h2>
      <img src={receipe.png} alt={label} style={{ width: '200px', height: '200px' }} />
      <p><strong>Cuisine Type:</strong> {cuisineType}</p>
      <p><strong>Meal Type:</strong> {mealType}</p>
      <p><strong>Total Time:</strong> {totalTime} minutes</p>
      <p><strong>Calories:</strong> {calories.toFixed(2)}</p>
      <h3>Ingredients:</h3>
      <ul>
        {ingredients.map((ingredient, index) => (
          <li key={index}>{ingredient.text}</li>
        ))}
      </ul>
      
    </div>
  );
};

export default RecipeDetails;

