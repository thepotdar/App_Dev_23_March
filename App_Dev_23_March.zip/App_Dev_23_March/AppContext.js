// AppContext.js

import React, { createContext, useState } from 'react';

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [searchHistory, setSearchHistory] = useState([]);
  const [favoriteRecipes, setFavoriteRecipes] = useState([]);
  
  // Method to add a recipe to favorites
  const addToFavorites = (recipe) => {
    setFavoriteRecipes([...favoriteRecipes, recipe]);
  };

  // Method to remove a recipe from favorites
  const removeFromFavorites = (recipeId) => {
    setFavoriteRecipes(favoriteRecipes.filter(recipe => recipe.id !== recipeId));
  };

  // Method to add a search query to search history
  const addToSearchHistory = (query) => {
    setSearchHistory([...searchHistory, query]);
  };

  // Clear search history
  const clearSearchHistory = () => {
    setSearchHistory([]);
  };

  // Context value object containing state and methods
  const contextValue = {
    user,
    setUser,
    searchHistory,
    addToSearchHistory,
    clearSearchHistory,
    favoriteRecipes,
    addToFavorites,
    removeFromFavorites
  };

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};

