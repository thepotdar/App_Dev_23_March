// RecipeCard.js

import React from 'react';

const RecipeCard = ({ recipe }) => {
  return (
    <div className="recipe-card">
      <h3>{recipe.label}</h3>
      <img src={recipe.image} alt={recipe.label} />
      <div>
        <h4>Ingredients:</h4>
        <ul>
          {recipe.ingredients.map((ingredient, index) => (
            <li key={index}>{ingredient.text}</li>
          ))}
        </ul>
      </div>
      <div>
        <h4>Nutritional Information:</h4>
        <ul>
          <li>Calories: {Math.round(recipe.calories)}</li>
          <li>Protein: {Math.round(recipe.totalNutrients.PROCNT.quantity)} {recipe.totalNutrients.PROCNT.unit}</li>
          <li>Fat: {Math.round(recipe.totalNutrients.FAT.quantity)} {recipe.totalNutrients.FAT.unit}</li>
          <li>Carbohydrates: {Math.round(recipe.totalNutrients.CHOCDF.quantity)} {recipe.totalNutrients.CHOCDF.unit}</li>
          {/* Add more nutritional information if available */}
        </ul>
      </div>
      <div>
        <h4>Preparation:</h4>
        <p>{recipe.preparation}</p>
      </div>
    </div>
  );
};

export default RecipeCard;

