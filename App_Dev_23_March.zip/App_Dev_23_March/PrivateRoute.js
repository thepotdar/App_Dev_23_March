import React, { useState } from 'react';
import { Route, Redirect } from 'react-router-dom';

const PrivateRoute = ({ component: Component, ...rest }) => {
  // Simulate authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  
 // Check if user is authenticated
const checkAuthentication = () => {

  // Logic to check if user is authenticated (e.g., check for authentication token)
  
  const token = localStorage.getItem('authToken');
  
  return !!token; // Convert token value to boolean (true if token exists, false if null or undefined)
};


  return (
    <Route
      {...rest}
      render={(props) =>
        checkAuthentication() ? (
          <Component {...props} />
        ) : (
          <Redirect to="/login" />
        )
      }
    />
  );
};

export default PrivateRoute;

